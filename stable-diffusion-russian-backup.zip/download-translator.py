from pathlib import Path
import urllib.request
p=Path(__file__).resolve().parent/'translation-ru-en'
p.mkdir(exist_ok=True)
for name in ['config.json','generation_config.json','pytorch_model.bin','source.spm','target.spm','tokenizer_config.json','vocab.json']:
    print(name,flush=True)
    urllib.request.urlretrieve('https://huggingface.co/Helsinki-NLP/opus-mt-ru-en/resolve/main/'+name,p/name)
