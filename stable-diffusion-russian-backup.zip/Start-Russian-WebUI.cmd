@echo off
cd /d "%~dp0stable-diffusion-webui"
set "TORCH_COMMAND=pip install torch==2.7.0 torchvision==0.22.0 --index-url https://download.pytorch.org/whl/cu128"
set "COMMANDLINE_ARGS=--medvram-sdxl --opt-sdp-attention --no-download-sd-model --autolaunch"
call webui.bat
