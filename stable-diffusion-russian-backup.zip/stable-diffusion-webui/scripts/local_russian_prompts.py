"""Translate Russian prompts locally using Helsinki-NLP/opus-mt-ru-en (CC BY 4.0)."""
import functools
import re
import threading
from pathlib import Path

import gradio as gr
import torch
from modules import scripts

_lock = threading.Lock()
_tokenizer = None
_model = None
_folder = Path(__file__).resolve().parents[2] / 'translation-ru-en'
_cyrillic = re.compile('[А-Яа-яЁё]')

@functools.lru_cache(maxsize=128)
def translate(text):
    global _tokenizer, _model
    if not text or not _cyrillic.search(text):
        return text
    with _lock:
        if _model is None:
            from transformers import MarianMTModel, MarianTokenizer
            _tokenizer = MarianTokenizer.from_pretrained(str(_folder), local_files_only=True)
            _model = MarianMTModel.from_pretrained(str(_folder), local_files_only=True).eval().cpu()
        # Keep LoRA tags intact; translate natural language separately.
        result = []
        for part in re.split(r'(<[^>]+>)', text):
            if part.startswith('<') or not _cyrillic.search(part):
                result.append(part)
                continue
            ids = _tokenizer.encode(part, add_special_tokens=False)
            chunks = []
            for start in range(0, len(ids), 384):
                encoded = torch.tensor([ids[start:start+384] + [_tokenizer.eos_token_id]])
                with torch.inference_mode():
                    generated = _model.generate(input_ids=encoded, max_new_tokens=512, num_beams=4)
                chunks.append(_tokenizer.decode(generated[0], skip_special_tokens=True))
            result.append(' '.join(chunks))
        return ' '.join(result).strip()

class Script(scripts.Script):
    def title(self):
        return 'Russian prompt translation'

    def show(self, is_img2img):
        return scripts.AlwaysVisible

    def ui(self, is_img2img):
        return [gr.Checkbox(value=True, label='Translate Russian prompts locally',
                            info='Local Russian-to-English translation before generation.')]

    def before_process(self, p, enabled=True):
        if not enabled:
            return
        for field in ('prompt', 'negative_prompt', 'hr_prompt', 'hr_negative_prompt'):
            value = getattr(p, field, None)
            if isinstance(value, str) and _cyrillic.search(value):
                converted = translate(value)
                p.extra_generation_params['Original Russian ' + field] = value
                setattr(p, field, converted)
            elif isinstance(value, list):
                setattr(p, field, [translate(x) for x in value])
